# Restaurant-Management-System
Desktop Application made using Tkinter in Python.
By Default the checkboxes are reset and quantity is zero.
On checking the Checkboxes user needs to enter the quantity of item desired.
Clicking on the Total button calculates the entire bill.
Reciept is used to maintain a record of items sold.
Reset Button can be used to disable all checkboxes and quantity textboxes.

<img src="https://github.com/ashnakapoor07/cafe-management-system/blob/master/rms.png">

